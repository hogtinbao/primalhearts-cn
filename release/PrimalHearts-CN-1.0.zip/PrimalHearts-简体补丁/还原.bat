@echo off
chcp 936 >nul
setlocal
set "PACK=%~dp0"
pushd "%PACK%.."
set "GAME=%CD%"
popd

if exist "%GAME%\primalhearts.orig.exe" (
    copy /y "%GAME%\primalhearts.orig.exe" "%GAME%\primalhearts.exe" >nul
    del "%GAME%\primalhearts.orig.exe"
    echo [���] �������ѻ�ԭ
)
if exist "%GAME%\script.noa.bak" (
    copy /y "%GAME%\script.noa.bak" "%GAME%\script.noa" >nul
    echo [���] script.noa �ѻ�ԭ
)
pause
